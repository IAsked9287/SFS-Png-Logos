# SFS-Png-Logos
Adds more textures to Spaceflight Simulator specifically png ones

**BP editing is highly advised, and some textures might not work with (ex: size 4 fuel tanks so use Bp editing**)

**I reccommend using these as fairings and not fuel tanks to overlap fuel tanks which is the purpose of the logos, use a bp editor mod or just normal bp editing to resize the textures to your liking.**

This pack indludes:

Brazilian Space Agency Logo

Italian Space Agency Logo

Apollo 11 Logo x2

Artemis Logo x2

Australian Space Agency Logo

Blank transparent texture (just because)

Blue Origin Logo

Canadian Space Agency Logo

French Space Agency Logo

Challenger Logo

Chinese Space Agency Logo

German Space Agency Logo

Egyptian Space Agency Logo

ESA logo x4

Indian Space Agency Logo

Iranian Space Agency Logo

ISS emblem

Japanese Space Agency Logo

Korean Space Agency Logo

Kenyan Space Agency Logo

Indonesian Space Agency Logo

Lockheed Martin Logo

Argentine Space Agency Logo

NASA logo x3

Nigerian Space Agency Logo

Romanian Space Agency Logo

Roscosmos Logo x2

Space Shuttle Logo

SpaceX Logo x3

Tesla Logo

Toyota Logo

Turkish Space Agency Logo

UK Space Agency Logo

ULA Logo x2

UN Logo

UAE Space Agency Logo

Voyager Logo

Put the texture pack (Png.Textures.BP.preview.zip) into "Steam\steamapps\common\Spaceflight Simulator\Spaceflight Simulator Game\Mods\Custom Assets\Texture Packs" and put the bp file (Lots.of.Logos.zip) into "Steam\steamapps\common\Spaceflight Simulator\Spaceflight Simulator Game\Saving\Blueprints"

Credits to: (Discord user); I_Asked#9287 (Github user); IAsked9287
